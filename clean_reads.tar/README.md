# clean reads

Short pipeline to map reads to a reference genome and filter those reads correctly mapping 
